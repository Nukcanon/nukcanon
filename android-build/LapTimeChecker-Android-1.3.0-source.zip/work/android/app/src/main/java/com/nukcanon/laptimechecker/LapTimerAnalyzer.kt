package com.nukcanon.laptimechecker

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfInt
import org.opencv.imgproc.Imgproc
import org.opencv.video.BackgroundSubtractorMOG2
import org.opencv.video.Video
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

class LapTimerAnalyzer(
    @Volatile private var sensitivity: Double,
    @Volatile private var cooldownMillis: Long,
    @Volatile private var history: Int,
    private val onLapDetected: () -> Unit,
    private val onDebugFrame: ((Bitmap) -> Unit)?,
    screenRoi: RectF? = null,
    viewSize: Size? = null
) : ImageAnalysis.Analyzer {

    @Volatile var isDebugMode = false

    private enum class State { LEARNING, DETECTING }

    private var currentState = State.LEARNING
    private var valueSubtractor = createSubtractor()
    private var saturationSubtractor = createSubtractor()
    private var hueSubtractor = createSubtractor()

    @Volatile private var screenRoi = screenRoi?.let(::RectF)
    @Volatile private var viewSize = viewSize
    @Volatile private var mirrored = false
    @Volatile private var pendingBackgroundReset = false

    @Volatile var roiRect: org.opencv.core.Rect? = null
        private set

    private var lastDetectionTime = 0L
    private var learningFrameCount = 0

    private val hsvFrame = Mat()
    private val valueMask = Mat()
    private val saturationMask = Mat()
    private val hueMask = Mat()
    private val finalMask = Mat()
    private val argbToRgbaMap = MatOfInt(1, 0, 2, 1, 3, 2, 0, 3)

    fun setScreenRoi(rect: RectF, size: Size) {
        screenRoi = RectF(rect)
        viewSize = size
        roiRect = null
        pendingBackgroundReset = true
    }

    fun hasRoi(): Boolean = screenRoi != null

    fun updateSettings(newSensitivity: Double, newCooldown: Long, newHistory: Int) {
        sensitivity = newSensitivity
        cooldownMillis = newCooldown
        if (history != newHistory) {
            history = newHistory
            pendingBackgroundReset = true
        }
    }

    fun resetBackground() {
        pendingBackgroundReset = true
    }

    fun invalidateRoiMapping() {
        roiRect = null
        pendingBackgroundReset = true
    }

    fun setMirrored(value: Boolean) {
        if (mirrored != value) {
            mirrored = value
            invalidateRoiMapping()
        }
    }

    private fun createSubtractor(): BackgroundSubtractorMOG2 =
        Video.createBackgroundSubtractorMOG2(history, 16.0, false)

    private fun resetBackgroundNow() {
        valueSubtractor.clear()
        saturationSubtractor.clear()
        hueSubtractor.clear()
        valueSubtractor = createSubtractor()
        saturationSubtractor = createSubtractor()
        hueSubtractor = createSubtractor()
        currentState = State.LEARNING
        learningFrameCount = 0
        pendingBackgroundReset = false
    }

    override fun analyze(imageProxy: ImageProxy) {
        var rgbaMat: Mat? = null
        var rotatedMat: Mat? = null
        var roiFrame: Mat? = null
        val hsvChannels = ArrayList<Mat>(3)

        try {
            if (pendingBackgroundReset) resetBackgroundNow()

            rgbaMat = imageProxy.toRgbaMat() ?: return
            rotatedMat = Mat()
            when (imageProxy.imageInfo.rotationDegrees) {
                90 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_90_CLOCKWISE)
                180 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_180)
                270 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_90_COUNTERCLOCKWISE)
                else -> rgbaMat.copyTo(rotatedMat)
            }

            val selectedScreenRoi = screenRoi ?: return
            val selectedViewSize = viewSize ?: return
            if (roiRect == null) {
                roiRect = transformScreenRectToImageRect(
                    selectedScreenRoi,
                    selectedViewSize,
                    rotatedMat.cols(),
                    rotatedMat.rows()
                )
            }

            val roi = roiRect ?: return
            if (roi.x < 0 || roi.y < 0 || roi.width <= 0 || roi.height <= 0 ||
                roi.x + roi.width > rotatedMat.cols() || roi.y + roi.height > rotatedMat.rows()
            ) {
                roiRect = null
                return
            }

            roiFrame = rotatedMat.submat(roi)
            Imgproc.cvtColor(roiFrame, hsvFrame, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(hsvFrame, hsvFrame, Imgproc.COLOR_RGB2HSV)
            Core.split(hsvFrame, hsvChannels)
            if (hsvChannels.size < 3) return

            val hChannel = hsvChannels[0]
            val sChannel = hsvChannels[1]
            val vChannel = hsvChannels[2]
            val now = SystemClock.elapsedRealtime()

            when (currentState) {
                State.LEARNING -> {
                    hueSubtractor.apply(hChannel, hueMask)
                    saturationSubtractor.apply(sChannel, saturationMask)
                    valueSubtractor.apply(vChannel, valueMask)
                    learningFrameCount++

                    if (learningFrameCount >= FRAMES_TO_LEARN &&
                        now - lastDetectionTime >= cooldownMillis
                    ) {
                        currentState = State.DETECTING
                    }
                }

                State.DETECTING -> {
                    hueSubtractor.apply(hChannel, hueMask)
                    saturationSubtractor.apply(sChannel, saturationMask)
                    valueSubtractor.apply(vChannel, valueMask)
                    combineMasks()

                    val totalPixels = roiFrame.rows() * roiFrame.cols()
                    if (totalPixels > 0) {
                        val motionPercentage =
                            Core.countNonZero(finalMask).toDouble() / totalPixels * 100.0
                        if (motionPercentage > sensitivity) {
                            onLapDetected()
                            lastDetectionTime = now
                            resetBackgroundNow()
                        }
                    }
                }
            }

            if (isDebugMode) {
                combineMasks()
                updateDebugFrame(finalMask)
            }
        } catch (error: Exception) {
            Log.e(TAG, "Frame analysis failed", error)
            roiRect = null
        } finally {
            hsvChannels.forEach { it.release() }
            roiFrame?.release()
            rotatedMat?.release()
            rgbaMat?.release()
            imageProxy.close()
        }
    }

    private fun combineMasks() {
        if (hueMask.empty() || saturationMask.empty() || valueMask.empty()) return
        Core.bitwise_or(saturationMask, hueMask, finalMask)
        Core.bitwise_or(finalMask, valueMask, finalMask)
    }

    private fun transformScreenRectToImageRect(
        screenRect: RectF,
        previewSize: Size,
        imageWidth: Int,
        imageHeight: Int
    ): org.opencv.core.Rect {
        val scale = max(
            previewSize.width.toFloat() / imageWidth,
            previewSize.height.toFloat() / imageHeight
        )
        val offsetX = (previewSize.width - imageWidth * scale) / 2f
        val offsetY = (previewSize.height - imageHeight * scale) / 2f

        val screenLeft = if (mirrored) previewSize.width - screenRect.right else screenRect.left
        val screenRight = if (mirrored) previewSize.width - screenRect.left else screenRect.right

        val left = floor((screenLeft - offsetX) / scale)
            .toInt().coerceIn(0, imageWidth - 1)
        val top = floor((screenRect.top - offsetY) / scale)
            .toInt().coerceIn(0, imageHeight - 1)
        val right = ceil((screenRight - offsetX) / scale)
            .toInt().coerceIn(left + 1, imageWidth)
        val bottom = ceil((screenRect.bottom - offsetY) / scale)
            .toInt().coerceIn(top + 1, imageHeight)

        return org.opencv.core.Rect(left, top, right - left, bottom - top)
    }

    private fun updateDebugFrame(mat: Mat) {
        if (mat.empty()) return
        val bitmap = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, bitmap)
        onDebugFrame?.invoke(bitmap)
    }

    private fun ImageProxy.toRgbaMat(): Mat? {
        if (format != PixelFormat.RGBA_8888 || planes.isEmpty()) return null

        val plane = planes[0]
        val buffer = plane.buffer.duplicate()
        val rowBytes = width * 4
        val bytes = ByteArray(rowBytes * height)
        val base = buffer.position()

        if (plane.pixelStride == 4) {
            for (row in 0 until height) {
                buffer.position(base + row * plane.rowStride)
                buffer.get(bytes, row * rowBytes, rowBytes)
            }
        } else {
            for (row in 0 until height) {
                val rowStart = base + row * plane.rowStride
                for (column in 0 until width) {
                    val source = rowStart + column * plane.pixelStride
                    val target = (row * width + column) * 4
                    bytes[target] = buffer.get(source)
                    bytes[target + 1] = buffer.get(source + 1)
                    bytes[target + 2] = buffer.get(source + 2)
                    bytes[target + 3] = buffer.get(source + 3)
                }
            }
        }

        val argbMat = Mat(height, width, CvType.CV_8UC4)
        val rgbaMat = Mat(height, width, CvType.CV_8UC4)
        return try {
            argbMat.put(0, 0, bytes)
            Core.mixChannels(listOf(argbMat), listOf(rgbaMat), argbToRgbaMap)
            rgbaMat
        } catch (error: Exception) {
            rgbaMat.release()
            Log.e(TAG, "RGBA conversion failed", error)
            null
        } finally {
            argbMat.release()
        }
    }

    fun release() {
        valueSubtractor.clear()
        saturationSubtractor.clear()
        hueSubtractor.clear()
        hsvFrame.release()
        valueMask.release()
        saturationMask.release()
        hueMask.release()
        finalMask.release()
        argbToRgbaMap.release()
    }

    companion object {
        private const val TAG = "LapTimerAnalyzer"
        private const val FRAMES_TO_LEARN = 30
    }
}
