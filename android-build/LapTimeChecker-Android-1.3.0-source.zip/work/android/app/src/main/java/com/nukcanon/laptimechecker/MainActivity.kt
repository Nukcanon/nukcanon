package com.nukcanon.laptimechecker

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.nukcanon.laptimechecker.databinding.ActivityMainBinding
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.util.Size
import android.util.TypedValue
import android.net.Uri
import android.provider.Settings
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var imageAnalysis: ImageAnalysis? = null
    private var lapTimerAnalyzer: LapTimerAnalyzer? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isDebugViewOn = false
    private var lastCameraFacing: String? = null

    private var isTimerRunning = false
    private var startTime: Long = 0
    private val lapTimes = mutableListOf<String>()
    private lateinit var lapTimeAdapter: LapTimeAdapter

    private val stopwatchHandler = Handler(Looper.getMainLooper())
    private lateinit var stopwatchRunnable: Runnable
    private var hasStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            val actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, resources.displayMetrics)
            val newToolbarHeight = (actionBarHeight * 0.8).toInt()
            val params = binding.toolbar.layoutParams
            params.height = newToolbarHeight
            binding.toolbar.layoutParams = params
        }

        lapTimeAdapter = LapTimeAdapter(lapTimes)
        binding.lapTimeRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.lapTimeRecyclerView.adapter = lapTimeAdapter

        loadLapTimes()

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        setupListeners()
        setupStopwatch()
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnResetBackground.visibility = View.GONE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        binding.btnStartStop.setOnClickListener {
            if (isTimerRunning) {
                isTimerRunning = false
                hasStarted = false
                startTime = 0L
                binding.btnStartStop.text = "측정 시작"
                binding.drawView.isDrawingEnabled = true
                stopwatchHandler.removeCallbacks(stopwatchRunnable)
                binding.stopwatchTextView.isVisible = false
            } else {
                if (lapTimerAnalyzer?.hasRoi() != true) {
                    Toast.makeText(this, "먼저 감지 영역을 설정해주세요.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                lapTimerAnalyzer?.resetBackground()
                isTimerRunning = true
                hasStarted = false
                binding.btnStartStop.text = "측정 중지"
                binding.drawView.isDrawingEnabled = false
            }
        }
        binding.btnClear.setOnClickListener {
            lapTimes.clear()
            lapTimeAdapter.notifyDataSetChanged()
            saveLapTimes()
        }
        binding.btnResetBackground.setOnClickListener {
            lapTimerAnalyzer?.resetBackground()
            Toast.makeText(this, "배경 모델이 초기화되었습니다.", Toast.LENGTH_SHORT).show()
        }
        binding.drawView.onRectDrawn = { rect ->
            binding.infoTextView.isVisible = false
            setAnalyzerRoi(rect)
            positionDebugView(rect)
        }
        binding.btnToggleDebug.setOnClickListener {
            isDebugViewOn = !isDebugViewOn
            lapTimerAnalyzer?.isDebugMode = isDebugViewOn
            binding.debugImageView.visibility = if (isDebugViewOn) View.VISIBLE else View.GONE

            binding.btnResetBackground.visibility = if (isDebugViewOn) View.VISIBLE else View.GONE
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val cameraProvider = cameraProvider ?: return
        val rotation = binding.previewView.display.rotation

        val resolutionSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .build()

        val analysisResolutionSelector = ResolutionSelector.Builder()
            .setResolutionStrategy(
                ResolutionStrategy(
                    Size(1280, 720),
                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            )
            .build()

        val preview = Preview.Builder()
            .setResolutionSelector(resolutionSelector)
            .setTargetRotation(rotation)
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val sensitivity = prefs.getInt("sensitivity", 27).toDouble()
        val cooldown = prefs.getString("cooldown", "2000")?.toLongOrNull() ?: 2000L
        val history = prefs.getInt("background_history", 1000)
        val cameraFacing = prefs.getString("camera_facing", "back") ?: "back"
        val requestedCameraSelector = if (cameraFacing == "front") {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
        val useFrontCamera = try {
            cameraFacing == "front" && cameraProvider.hasCamera(requestedCameraSelector)
        } catch (error: CameraInfoUnavailableException) {
            Log.w(TAG, "Camera list unavailable", error)
            false
        }
        val cameraSelector = if (useFrontCamera) {
            requestedCameraSelector
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        if (cameraFacing == "front" && !useFrontCamera) {
            Toast.makeText(this, "전면 카메라를 찾지 못해 후면 카메라를 사용합니다.", Toast.LENGTH_SHORT).show()
        }

        if (lapTimerAnalyzer == null) {
            lapTimerAnalyzer = LapTimerAnalyzer(sensitivity, cooldown, history,
                { if (isTimerRunning) { runOnUiThread { handleLapDetection() } } },
                { debugBitmap -> runOnUiThread { binding.debugImageView.setImageBitmap(debugBitmap) } }
            )
        } else {
            lapTimerAnalyzer?.updateSettings(sensitivity, cooldown, history)
        }

        val activeCameraFacing = if (useFrontCamera) "front" else "back"
        if (lastCameraFacing != null && lastCameraFacing != activeCameraFacing) {
            lapTimerAnalyzer?.invalidateRoiMapping()
        }
        lapTimerAnalyzer?.setMirrored(useFrontCamera)
        lastCameraFacing = activeCameraFacing

        imageAnalysis = ImageAnalysis.Builder()
            .setResolutionSelector(analysisResolutionSelector)
            .setTargetRotation(rotation)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { it.setAnalyzer(cameraExecutor, lapTimerAnalyzer!!) }

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis)
        } catch (exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }
    }

    private fun handleLapDetection() {
        val currentTime = System.currentTimeMillis()
        if (!hasStarted) {
            hasStarted = true
            startTime = currentTime
            binding.stopwatchTextView.isVisible = true
            stopwatchHandler.post(stopwatchRunnable)
            return
        }
        val totalElapsedTime = currentTime - startTime
        if (totalElapsedTime < 500) { return }
        val timeText = formatTime(totalElapsedTime)
        val newLapText = "LAP ${lapTimes.size + 1}: $timeText"
        lapTimes.add(0, newLapText)
        lapTimeAdapter.notifyDataSetChanged()
        binding.lapTimeRecyclerView.scrollToPosition(0)
        saveLapTimes()
        startTime = currentTime
    }

    private fun setAnalyzerRoi(screenRect: RectF) {
        if (binding.previewView.width <= 0 || binding.previewView.height <= 0) {
            Toast.makeText(this, "카메라 준비 중입니다. 잠시 후 다시 시도해주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        val clippedRect = RectF(
            screenRect.left.coerceIn(0f, binding.previewView.width.toFloat()),
            screenRect.top.coerceIn(0f, binding.previewView.height.toFloat()),
            screenRect.right.coerceIn(0f, binding.previewView.width.toFloat()),
            screenRect.bottom.coerceIn(0f, binding.previewView.height.toFloat())
        )
        lapTimerAnalyzer?.setScreenRoi(
            clippedRect,
            Size(binding.previewView.width, binding.previewView.height)
        )
        Log.d("ROI_Debug", "Preview ROI: $clippedRect")
    }

    private fun positionDebugView(rect: RectF) {
        val params = binding.debugImageView.layoutParams as ConstraintLayout.LayoutParams
        params.width = rect.width().toInt()
        params.height = rect.height().toInt()
        params.topToTop = binding.previewView.id
        params.startToStart = binding.previewView.id
        params.bottomToBottom = ConstraintLayout.LayoutParams.UNSET
        params.endToEnd = ConstraintLayout.LayoutParams.UNSET
        params.topMargin = rect.top.toInt()
        params.marginStart = rect.left.toInt()
        binding.debugImageView.layoutParams = params
        Log.d("ROI_Debug", "Debug View positioned at: ${rect.left},${rect.top} size ${rect.width()}x${rect.height()}")
    }

    private fun setupStopwatch() {
        stopwatchRunnable = object : Runnable {
            override fun run() {
                if (isTimerRunning) {
                    val elapsedTime = System.currentTimeMillis() - startTime
                    binding.stopwatchTextView.text = formatTime(elapsedTime)
                    stopwatchHandler.postDelayed(this, 16)
                }
            }
        }
    }

    private fun formatTime(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        val hundredths = (millis % 1000) / 10
        return String.format("%02d:%02d.%02d", minutes, seconds, hundredths)
    }

    private fun saveLapTimes() {
        val prefs = getSharedPreferences("LapTimerPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val saveSet = lapTimes.mapIndexed { index, s -> "$index##$s" }.toSet()
        editor.putStringSet("lapTimes", saveSet)
        editor.apply()
    }

    private fun loadLapTimes() {
        val prefs = getSharedPreferences("LapTimerPrefs", Context.MODE_PRIVATE)
        val saveSet = prefs.getStringSet("lapTimes", null)
        if (saveSet != null) {
            lapTimes.clear()
            val sortedList = saveSet.map {
                val parts = it.split("##")
                parts[0].toInt() to parts[1]
            }.sortedBy { it.first }.map { it.second }
            lapTimes.addAll(sortedList)
            lapTimeAdapter.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        if (allPermissionsGranted()) {
            if (cameraProvider == null) startCamera() else bindCameraUseCases()
        }
        if (isTimerRunning && hasStarted) {
            stopwatchHandler.post(stopwatchRunnable)
        }
    }

    override fun onDestroy() {
        imageAnalysis?.clearAnalyzer()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        lapTimerAnalyzer?.release()
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                if (isTimerRunning) {
                    Toast.makeText(this, "측정을 중지한 후 설정을 변경해주세요.", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(this, SettingsActivity::class.java)
                    startActivity(intent)
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                showPermissionGuidanceDialog()
            }
        }
    }

    private fun showPermissionGuidanceDialog() {
        AlertDialog.Builder(this)
            .setTitle("권한 안내")
            .setMessage("앱의 핵심 기능인 랩타임 측정을 위해 카메라 권한이 반드시 필요합니다. 설정으로 이동하여 권한을 허용해주세요.")
            .setPositiveButton("설정으로 이동") { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivity(intent)
            }
            .setNegativeButton("종료") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)

        init {
            if (!OpenCVLoader.initDebug()) {
                Log.d(TAG, "OpenCV library not found.")
            } else {
                Log.d(TAG, "OpenCV library found.")
            }
        }
    }
}
