package com.nukcanon.laptimechecker

import android.os.Bundle
import android.view.View
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceFragmentCompat
import android.widget.Toast
import androidx.preference.Preference

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.settings, rootKey)

        val cooldownPreference: EditTextPreference? = findPreference("cooldown")
        cooldownPreference?.summaryProvider = EditTextPreference.SimpleSummaryProvider.getInstance()

        cooldownPreference?.onPreferenceChangeListener =
            Preference.OnPreferenceChangeListener { preference, newValue ->
                try {
                    val value = (newValue as String).toLong()
                    if (value < 1500) {
                        Toast.makeText(requireContext(), "지연 시간은 1500ms(1.5초) 이상이어야 합니다.", Toast.LENGTH_SHORT).show()
                        return@OnPreferenceChangeListener false
                    }
                } catch (e: NumberFormatException) {
                    Toast.makeText(requireContext(), "유효한 숫자를 입력해주세요.", Toast.LENGTH_SHORT).show()
                    return@OnPreferenceChangeListener false
                }
                true
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.setBackgroundColor(resources.getColor(android.R.color.white, null))
    }
}
