# LapTimeChecker 1.1.0

카메라 영상에서 사용자가 선택한 영역의 움직임을 감지해 랩타임을 기록하는 Android 앱입니다.

## 이번 수정 내용

- 세로/가로 화면에서 `PreviewView`의 `fillCenter` 확대 및 중앙 크롭과 동일한 방식으로 ROI 좌표를 변환합니다.
- 방향별 20%, 2.5% 수동 보정값을 제거했습니다.
- 화면 끝에서 시작한 드래그와 `ACTION_UP`의 마지막 좌표를 정상 처리합니다.
- CameraX의 RGBA 출력과 plane의 `rowStride`/`pixelStride`를 반영합니다.
- 모든 분석 경로에서 `ImageProxy.close()`와 OpenCV `Mat.release()`가 실행되도록 정리했습니다.
- 첫 통과 전 화면 복귀 시 잘못된 시간이 표시되던 문제를 수정했습니다.
- 시스템 시간 변경의 영향을 받지 않도록 타이머를 `SystemClock.elapsedRealtime()` 기반으로 변경했습니다.
- 설정 화면에서 돌아오면 감도, 대기시간, 배경 이력이 즉시 반영됩니다.
- 작은 마스크 노이즈를 줄이기 위해 3×3 morphology open 처리를 추가했습니다.
- 누락됐던 Gradle 실행 스크립트와 공식 OpenCV Maven 의존성을 사용합니다.

## 빌드

Android Studio에서 이 폴더를 열고 Gradle 동기화 후 `app` 모듈을 빌드하세요. JDK 17과 Android SDK 36을 사용합니다.
