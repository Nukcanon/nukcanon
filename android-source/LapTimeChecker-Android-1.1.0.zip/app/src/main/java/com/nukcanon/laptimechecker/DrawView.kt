package com.nukcanon.laptimechecker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

class DrawView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var isDrawingEnabled = true
    private val paint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 8f
        alpha = 200
    }
    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var hasSelection = false
    private val drawnRect = RectF()
    var onRectDrawn: ((RectF) -> Unit)? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (hasSelection) {
            canvas.drawRect(drawnRect, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isDrawingEnabled) return false

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                startX = event.x.coerceIn(0f, width.toFloat())
                startY = event.y.coerceIn(0f, height.toFloat())
                endX = startX
                endY = startY
                hasSelection = true
                updateRect()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                endX = event.x.coerceIn(0f, width.toFloat())
                endY = event.y.coerceIn(0f, height.toFloat())
                updateRect()
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                endX = event.x.coerceIn(0f, width.toFloat())
                endY = event.y.coerceIn(0f, height.toFloat())
                updateRect()
                if (drawnRect.width() > 10 && drawnRect.height() > 10) {
                    onRectDrawn?.invoke(RectF(drawnRect))
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return false
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun updateRect() {
        drawnRect.set(
            minOf(startX, endX),
            minOf(startY, endY),
            maxOf(startX, endX),
            maxOf(startY, endY)
        )
    }
}
