package com.nukcanon.laptimechecker

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LapTimeAdapter(private val lapTimes: List<String>) : RecyclerView.Adapter<LapTimeAdapter.LapViewHolder>() {

    class LapViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val lapText: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LapViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.lap_time_item, parent, false)
        return LapViewHolder(view)
    }

    override fun onBindViewHolder(holder: LapViewHolder, position: Int) {
        holder.lapText.text = lapTimes[position]
        holder.lapText.setTextColor(Color.WHITE)
        holder.lapText.textSize = 15f
    }

    override fun getItemCount() = lapTimes.size
}