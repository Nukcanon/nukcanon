package com.nukcanon.laptimechecker

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfInt
import org.opencv.core.Size as CvSize
import org.opencv.imgproc.Imgproc
import org.opencv.video.BackgroundSubtractorMOG2
import org.opencv.video.Video
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

class LapTimerAnalyzer(
    @Volatile private var sensitivity: Double,
    @Volatile private var cooldownMillis: Long,
    @Volatile private var history: Int,
    private val onLapDetected: () -> Unit,
    private val onDebugFrame: ((Bitmap) -> Unit)?,
    screenRoi: RectF? = null,
    viewSize: Size? = null
) : ImageAnalysis.Analyzer {

    @Volatile var isDebugMode: Boolean = false

    private enum class State { LEARNING, DETECTING }

    private var currentState = State.LEARNING
    private var valueSubtractor: BackgroundSubtractorMOG2 = createSubtractor()
    private var saturationSubtractor: BackgroundSubtractorMOG2 = createSubtractor()
    private var hueSubtractor: BackgroundSubtractorMOG2 = createSubtractor()

    @Volatile private var screenRoi: RectF? = screenRoi?.let(::RectF)
    @Volatile private var viewSize: Size? = viewSize
    @Volatile private var pendingBackgroundReset = false

    @Volatile var roiRect: org.opencv.core.Rect? = null
        private set

    private var lastDetectionTime = 0L
    private var learningFrameCount = 0

    private val hsvFrame = Mat()
    private val valueMask = Mat()
    private val saturationMask = Mat()
    private val hueMask = Mat()
    private val finalMask = Mat()
    private val noiseKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, CvSize(3.0, 3.0))
    private val argbToRgbaMap = MatOfInt(1, 0, 2, 1, 3, 2, 0, 3)

    fun setScreenRoi(rect: RectF, size: Size) {
        screenRoi = RectF(rect)
        viewSize = size
        roiRect = null
        pendingBackgroundReset = true
    }

    fun hasRoi(): Boolean = screenRoi != null

    fun updateSettings(newSensitivity: Double, newCooldown: Long, newHistory: Int) {
        sensitivity = newSensitivity
        cooldownMillis = newCooldown
        if (history != newHistory) {
            history = newHistory
            pendingBackgroundReset = true
        }
    }

    fun resetBackground() {
        pendingBackgroundReset = true
    }

    private fun createSubtractor(): BackgroundSubtractorMOG2 =
        Video.createBackgroundSubtractorMOG2(history, 16.0, false)

    private fun resetBackgroundNow() {
        valueSubtractor = createSubtractor()
        saturationSubtractor = createSubtractor()
        hueSubtractor = createSubtractor()
        currentState = State.LEARNING
        learningFrameCount = 0
        pendingBackgroundReset = false
        Log.d(TAG, "Background models reset. Starting learning phase.")
    }

    override fun analyze(imageProxy: ImageProxy) {
        var rgbaMat: Mat? = null
        var rotatedMat: Mat? = null
        var roiFrame: Mat? = null
        val hsvChannels = ArrayList<Mat>(3)

        try {
            if (pendingBackgroundReset) resetBackgroundNow()

            rgbaMat = imageProxy.toRgbaMat() ?: return
            rotatedMat = Mat()
            when (imageProxy.imageInfo.rotationDegrees) {
                90 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_90_CLOCKWISE)
                180 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_180)
                270 -> Core.rotate(rgbaMat, rotatedMat, Core.ROTATE_90_COUNTERCLOCKWISE)
                else -> rgbaMat.copyTo(rotatedMat)
            }

            val selectedScreenRect = screenRoi ?: return
            val selectedViewSize = viewSize ?: return
            if (roiRect == null) {
                roiRect = transformScreenRectToImageRect(
                    selectedScreenRect,
                    selectedViewSize,
                    rotatedMat.cols(),
                    rotatedMat.rows()
                )
            }

            val roi = roiRect ?: return
            if (roi.x < 0 || roi.y < 0 || roi.width <= 0 || roi.height <= 0 ||
                roi.x + roi.width > rotatedMat.cols() || roi.y + roi.height > rotatedMat.rows()
            ) {
                Log.e(TAG, "Invalid ROI $roi for ${rotatedMat.cols()}x${rotatedMat.rows()}")
                roiRect = null
                return
            }

            roiFrame = rotatedMat.submat(roi)
            Imgproc.cvtColor(roiFrame, hsvFrame, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(hsvFrame, hsvFrame, Imgproc.COLOR_RGB2HSV)
            Core.split(hsvFrame, hsvChannels)
            if (hsvChannels.size < 3) return

            val hChannel = hsvChannels[0]
            val sChannel = hsvChannels[1]
            val vChannel = hsvChannels[2]
            val now = SystemClock.elapsedRealtime()

            when (currentState) {
                State.LEARNING -> {
                    hueSubtractor.apply(hChannel, hueMask)
                    saturationSubtractor.apply(sChannel, saturationMask)
                    valueSubtractor.apply(vChannel, valueMask)
                    learningFrameCount++

                    if (learningFrameCount >= FRAMES_TO_LEARN && now - lastDetectionTime >= cooldownMillis) {
                        currentState = State.DETECTING
                        Log.d(TAG, "Learning complete. Switching to detection.")
                    }
                }

                State.DETECTING -> {
                    hueSubtractor.apply(hChannel, hueMask)
                    saturationSubtractor.apply(sChannel, saturationMask)
                    valueSubtractor.apply(vChannel, valueMask)
                    combineAndCleanMasks()

                    val totalPixels = roiFrame.rows() * roiFrame.cols()
                    if (totalPixels > 0) {
                        val motionPercentage = Core.countNonZero(finalMask).toDouble() / totalPixels * 100.0
                        Log.d(TAG, "Motion: %.2f%%".format(motionPercentage))
                        if (motionPercentage > sensitivity) {
                            onLapDetected()
                            lastDetectionTime = now
                            resetBackgroundNow()
                        }
                    }
                }
            }

            if (isDebugMode) {
                combineAndCleanMasks()
                updateDebugFrame(finalMask)
            }
        } catch (error: Exception) {
            Log.e(TAG, "Frame analysis failed", error)
            roiRect = null
        } finally {
            hsvChannels.forEach { it.release() }
            roiFrame?.release()
            rotatedMat?.release()
            rgbaMat?.release()
            imageProxy.close()
        }
    }

    private fun combineAndCleanMasks() {
        if (hueMask.empty() || saturationMask.empty() || valueMask.empty()) return
        Core.bitwise_or(saturationMask, hueMask, finalMask)
        Core.bitwise_or(finalMask, valueMask, finalMask)
        Imgproc.morphologyEx(finalMask, finalMask, Imgproc.MORPH_OPEN, noiseKernel)
    }

    /**
     * PreviewView의 FILL_CENTER와 같은 확대율을 사용한다. 영상이 화면보다 커져 잘린 경우
     * offset은 음수가 되며, 세로/가로 방향 모두 같은 식으로 정확히 역변환된다.
     */
    private fun transformScreenRectToImageRect(
        screenRect: RectF,
        previewSize: Size,
        imageWidth: Int,
        imageHeight: Int
    ): org.opencv.core.Rect {
        require(previewSize.width > 0 && previewSize.height > 0)
        require(imageWidth > 0 && imageHeight > 0)

        val scale = max(
            previewSize.width.toFloat() / imageWidth.toFloat(),
            previewSize.height.toFloat() / imageHeight.toFloat()
        )
        val renderedWidth = imageWidth * scale
        val renderedHeight = imageHeight * scale
        val offsetX = (previewSize.width - renderedWidth) / 2f
        val offsetY = (previewSize.height - renderedHeight) / 2f

        val left = floor((screenRect.left - offsetX) / scale).toInt().coerceIn(0, imageWidth - 1)
        val top = floor((screenRect.top - offsetY) / scale).toInt().coerceIn(0, imageHeight - 1)
        val right = ceil((screenRect.right - offsetX) / scale).toInt().coerceIn(left + 1, imageWidth)
        val bottom = ceil((screenRect.bottom - offsetY) / scale).toInt().coerceIn(top + 1, imageHeight)

        return org.opencv.core.Rect(left, top, right - left, bottom - top).also {
            Log.d(
                TAG,
                "ROI screen=$screenRect, view=${previewSize.width}x${previewSize.height}, " +
                    "image=${imageWidth}x$imageHeight, scale=$scale, offset=($offsetX,$offsetY), mapped=$it"
            )
        }
    }

    private fun updateDebugFrame(mat: Mat) {
        if (mat.empty()) return
        val debugBitmap = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, debugBitmap)
        onDebugFrame?.invoke(debugBitmap)
    }

    /** CameraX가 변환한 ARGB plane을 rowStride까지 반영해 OpenCV RGBA Mat으로 만든다. */
    private fun ImageProxy.toRgbaMat(): Mat? {
        if (format != PixelFormat.RGBA_8888 || planes.isEmpty()) {
            Log.e(TAG, "Unsupported image format: $format")
            return null
        }

        val frameWidth = width
        val frameHeight = height
        val plane = planes[0]
        val buffer = plane.buffer.duplicate()
        val bufferBase = buffer.position()
        val argbBytes = ByteArray(frameWidth * frameHeight * 4)

        for (row in 0 until frameHeight) {
            val rowStart = bufferBase + row * plane.rowStride
            for (column in 0 until frameWidth) {
                val inputIndex = rowStart + column * plane.pixelStride
                val outputIndex = (row * frameWidth + column) * 4
                argbBytes[outputIndex] = buffer.get(inputIndex)
                argbBytes[outputIndex + 1] = buffer.get(inputIndex + 1)
                argbBytes[outputIndex + 2] = buffer.get(inputIndex + 2)
                argbBytes[outputIndex + 3] = buffer.get(inputIndex + 3)
            }
        }

        val argbMat = Mat(frameHeight, frameWidth, CvType.CV_8UC4)
        val rgbaMat = Mat(frameHeight, frameWidth, CvType.CV_8UC4)
        return try {
            argbMat.put(0, 0, argbBytes)
            Core.mixChannels(
                listOf(argbMat),
                listOf(rgbaMat),
                argbToRgbaMap
            )
            rgbaMat
        } catch (error: Exception) {
            rgbaMat.release()
            Log.e(TAG, "ARGB conversion failed", error)
            null
        } finally {
            argbMat.release()
        }
    }

    fun release() {
        hsvFrame.release()
        valueMask.release()
        saturationMask.release()
        hueMask.release()
        finalMask.release()
        noiseKernel.release()
        argbToRgbaMap.release()
    }

    companion object {
        private const val TAG = "LapTimerAnalyzer"
        private const val FRAMES_TO_LEARN = 30
    }
}
