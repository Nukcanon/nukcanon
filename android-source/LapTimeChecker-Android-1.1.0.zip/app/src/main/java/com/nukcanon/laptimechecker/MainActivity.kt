package com.nukcanon.laptimechecker

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.nukcanon.laptimechecker.databinding.ActivityMainBinding
import org.opencv.android.OpenCVLoader
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.util.Size
import android.util.TypedValue
import android.net.Uri
import android.provider.Settings
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private var imageAnalysis: ImageAnalysis? = null
    private var lapTimerAnalyzer: LapTimerAnalyzer? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var isDebugViewOn = false

    private var isTimerRunning = false
    private var startTime: Long = 0
    private val lapTimes = mutableListOf<String>()
    private lateinit var lapTimeAdapter: LapTimeAdapter

    private val stopwatchHandler = Handler(Looper.getMainLooper())
    private lateinit var stopwatchRunnable: Runnable
    private var hasStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val tv = TypedValue()
        if (theme.resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            val actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, resources.displayMetrics)
            // 2. 높이의 80%를 계산합니다.
            val newToolbarHeight = (actionBarHeight * 0.8).toInt()
            // 3. 계산된 높이를 툴바에 적용합니다.
            val params = binding.toolbar.layoutParams
            params.height = newToolbarHeight
            binding.toolbar.layoutParams = params
        }

        lapTimeAdapter = LapTimeAdapter(lapTimes)
        binding.lapTimeRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.lapTimeRecyclerView.adapter = lapTimeAdapter

        loadLapTimes()

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        setupListeners()
        setupStopwatch()
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnResetBackground.visibility = View.GONE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupListeners() {
        binding.btnStartStop.setOnClickListener {
            if (isTimerRunning) {
                isTimerRunning = false
                hasStarted = false
                startTime = 0L
                binding.btnStartStop.text = "측정 시작"
                binding.drawView.isDrawingEnabled = true
                stopwatchHandler.removeCallbacks(stopwatchRunnable)
                binding.stopwatchTextView.isVisible = false
            } else {
                if (lapTimerAnalyzer?.hasRoi() != true) {
                    Toast.makeText(this, "먼저 감지 영역을 설정해주세요.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                isTimerRunning = true
                hasStarted = false
                binding.btnStartStop.text = "측정 중지"
                binding.drawView.isDrawingEnabled = false
            }
        }
        binding.btnClear.setOnClickListener {
            lapTimes.clear()
            lapTimeAdapter.notifyDataSetChanged()
            saveLapTimes()
        }
        binding.btnResetBackground.setOnClickListener {
            lapTimerAnalyzer?.resetBackground()
            Toast.makeText(this, "배경 모델이 초기화되었습니다.", Toast.LENGTH_SHORT).show()
        }
        binding.drawView.onRectDrawn = { rect ->
            binding.infoTextView.isVisible = false
            setAnalyzerRoi(rect)
            positionDebugView(rect)
        }
        binding.btnToggleDebug.setOnClickListener {
            // 버튼을 누를 때마다 상태를 반전시킵니다.
            isDebugViewOn = !isDebugViewOn

            // 변경된 상태를 분석기와 이미지 뷰에 적용합니다.
            lapTimerAnalyzer?.isDebugMode = isDebugViewOn
            binding.debugImageView.visibility = if (isDebugViewOn) View.VISIBLE else View.GONE

            binding.btnResetBackground.visibility = if (isDebugViewOn) View.VISIBLE else View.GONE
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val cameraProvider = cameraProvider ?: return
        val rotation = binding.previewView.display.rotation

        // 1. 새로운 ResolutionSelector를 만듭니다.
        val resolutionSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .build()

        // 2. Preview 빌더에 적용합니다.
        val preview = Preview.Builder()
            .setResolutionSelector(resolutionSelector) // .setTargetAspectRatio 대신 사용
            .setTargetRotation(rotation)
            .build()
            .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val sensitivity = prefs.getInt("sensitivity", 5).toDouble()
        val cooldown = prefs.getString("cooldown", "2000")?.toLongOrNull() ?: 2000L
        val history = prefs.getInt("background_history", 1000)

        if (lapTimerAnalyzer == null) {
            lapTimerAnalyzer = LapTimerAnalyzer(sensitivity, cooldown, history,
                { if (isTimerRunning) { runOnUiThread { handleLapDetection() } } },
                { debugBitmap -> runOnUiThread { binding.debugImageView.setImageBitmap(debugBitmap) } }
            )
        } else {
            lapTimerAnalyzer?.updateSettings(sensitivity, cooldown, history)
        }

        // 3. ImageAnalysis 빌더에도 동일하게 적용합니다.
        imageAnalysis = ImageAnalysis.Builder()
            .setResolutionSelector(resolutionSelector) // .setTargetAspectRatio 대신 사용
            .setTargetRotation(rotation)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { it.setAnalyzer(cameraExecutor, lapTimerAnalyzer!!) }

        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageAnalysis)
        } catch (exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }
    }

    private fun handleLapDetection() {
        val currentTime = SystemClock.elapsedRealtime()
        if (!hasStarted) {
            hasStarted = true
            startTime = currentTime
            binding.stopwatchTextView.isVisible = true
            stopwatchHandler.post(stopwatchRunnable)
            return
        }
        val totalElapsedTime = currentTime - startTime
        if (totalElapsedTime < 500) { return }
        val timeText = formatTime(totalElapsedTime)
        val newLapText = "LAP ${lapTimes.size + 1}: $timeText"
        lapTimes.add(0, newLapText)
        lapTimeAdapter.notifyDataSetChanged()
        binding.lapTimeRecyclerView.scrollToPosition(0)
        saveLapTimes()
        startTime = currentTime
    }

    private fun setAnalyzerRoi(screenRect: RectF) {
        if (binding.previewView.width <= 0 || binding.previewView.height <= 0) {
            Toast.makeText(this, "카메라 준비 중입니다. 잠시 후 다시 시도해주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        // DrawView와 PreviewView의 크기와 위치가 같으므로 화면 좌표를 그대로 넘긴다.
        // 실제 fillCenter 확대/크롭 보정은 분석 프레임의 정확한 크기를 아는 Analyzer에서 수행한다.
        val clippedRect = RectF(
            screenRect.left.coerceIn(0f, binding.previewView.width.toFloat()),
            screenRect.top.coerceIn(0f, binding.previewView.height.toFloat()),
            screenRect.right.coerceIn(0f, binding.previewView.width.toFloat()),
            screenRect.bottom.coerceIn(0f, binding.previewView.height.toFloat())
        )
        lapTimerAnalyzer?.setScreenRoi(
            clippedRect,
            Size(binding.previewView.width, binding.previewView.height)
        )
        Log.d("ROI_Debug", "Preview ROI: $clippedRect, view=${binding.previewView.width}x${binding.previewView.height}")
    }

    private fun positionDebugView(rect: RectF) { // 인자로 실제 프리뷰 렌더링 영역 rect를 받습니다.
        val params = binding.debugImageView.layoutParams as ConstraintLayout.LayoutParams
        params.width = rect.width().toInt()
        params.height = rect.height().toInt()
        params.topToTop = binding.previewView.id
        params.startToStart = binding.previewView.id
        params.bottomToBottom = ConstraintLayout.LayoutParams.UNSET
        params.endToEnd = ConstraintLayout.LayoutParams.UNSET
        params.topMargin = rect.top.toInt()
        params.marginStart = rect.left.toInt()
        binding.debugImageView.layoutParams = params
        Log.d("ROI_Debug", "Debug View positioned at: ${rect.left},${rect.top} size ${rect.width()}x${rect.height()}")
    }

    private fun setupStopwatch() {
        stopwatchRunnable = object : Runnable {
            override fun run() {
                if (isTimerRunning && hasStarted) {
                    val elapsedTime = SystemClock.elapsedRealtime() - startTime
                    binding.stopwatchTextView.text = formatTime(elapsedTime)
                    stopwatchHandler.postDelayed(this, 16)
                }
            }
        }
    }

    private fun formatTime(millis: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        // 1. 100으로 나누던 것을 10으로 나눠서 소수점 두 자리를 구합니다.
        val hundredths = (millis % 1000) / 10
        // 2. String.format 에서 %d 를 %02d 로 바꿔 항상 두 자리로 표시되게 합니다. (예: .7초 -> .07초)
        return String.format("%02d:%02d.%02d", minutes, seconds, hundredths)
    }

    private fun saveLapTimes() {
        val prefs = getSharedPreferences("LapTimerPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val saveSet = lapTimes.mapIndexed { index, s -> "$index##$s" }.toSet()
        editor.putStringSet("lapTimes", saveSet)
        editor.apply()
    }

    private fun loadLapTimes() {
        val prefs = getSharedPreferences("LapTimerPrefs", Context.MODE_PRIVATE)
        val saveSet = prefs.getStringSet("lapTimes", null)
        if (saveSet != null) {
            lapTimes.clear()
            val sortedList = saveSet.map {
                val parts = it.split("##")
                parts[0].toInt() to parts[1]
            }.sortedBy { it.first }.map { it.second }
            lapTimes.addAll(sortedList)
            lapTimeAdapter.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        if (allPermissionsGranted()) {
            if (cameraProvider == null) startCamera() else bindCameraUseCases()
        }
        if (isTimerRunning && hasStarted) {
            stopwatchHandler.post(stopwatchRunnable)
        }
    }

    override fun onPause() {
        stopwatchHandler.removeCallbacks(stopwatchRunnable)
        super.onPause()
    }

    override fun onDestroy() {
        imageAnalysis?.clearAnalyzer()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        try {
            cameraExecutor.awaitTermination(500, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        lapTimerAnalyzer?.release()
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                if (isTimerRunning) {
                    Toast.makeText(this, "측정을 중지한 후 설정을 변경해주세요.", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(this, SettingsActivity::class.java)
                    startActivity(intent)
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                // 권한이 거부되면 안내 다이얼로그를 보여줍니다.
                showPermissionGuidanceDialog()
            }
        }
    }

    private fun showPermissionGuidanceDialog() {
        AlertDialog.Builder(this)
            .setTitle("권한 안내")
            .setMessage("앱의 핵심 기능인 랩타임 측정을 위해 카메라 권한이 반드시 필요합니다. 설정으로 이동하여 권한을 허용해주세요.")
            .setPositiveButton("설정으로 이동") { _, _ ->
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivity(intent)
            }
            .setNegativeButton("종료") { _, _ ->
                finish()
            }
            .setCancelable(false) // 뒤로가기 버튼으로 다이얼로그를 닫지 못하게 설정
            .show()
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)

        init {
            if (!OpenCVLoader.initDebug()) {
                Log.d(TAG, "OpenCV library not found.")
            } else {
                Log.d(TAG, "OpenCV library found.")
            }
        }
    }
}
