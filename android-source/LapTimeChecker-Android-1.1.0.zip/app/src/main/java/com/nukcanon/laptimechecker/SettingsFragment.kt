package com.nukcanon.laptimechecker // 본인 패키지 이름 확인

import android.os.Bundle
import android.view.View
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceFragmentCompat
import android.widget.Toast
import androidx.preference.Preference

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.settings, rootKey)

        // EditTextPreference의 요약(summary)을 현재 값으로 설정
        val cooldownPreference: EditTextPreference? = findPreference("cooldown")
        cooldownPreference?.summaryProvider = EditTextPreference.SimpleSummaryProvider.getInstance()

        cooldownPreference?.onPreferenceChangeListener =
            Preference.OnPreferenceChangeListener { preference, newValue ->
                try {
                    val value = (newValue as String).toLong()
                    if (value < 1500) {
                        Toast.makeText(requireContext(), "지연 시간은 1500ms(1.5초) 이상이어야 합니다.", Toast.LENGTH_SHORT).show()
                        return@OnPreferenceChangeListener false // false를 반환하면 값이 저장되지 않음
                    }
                } catch (e: NumberFormatException) {
                    Toast.makeText(requireContext(), "유효한 숫자를 입력해주세요.", Toast.LENGTH_SHORT).show()
                    return@OnPreferenceChangeListener false // 숫자가 아니어도 저장되지 않음
                }
                true // 모든 검사를 통과하면 true를 반환하여 값을 저장
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // 흰색 배경 설정
        view.setBackgroundColor(resources.getColor(android.R.color.white, null))
    }
}